const AWS = require('aws-sdk')

AWS.config.update({ region: process.env.AWS_REGION }) // Needed?

const DDB = new AWS.DynamoDB({ apiVersion: '2012-10-08' })

const connect = async (connectionId) => {
  try {
    await DDB.putItem({
      TableName: process.env.CONNECTIONS_TABLE,
      Item: {
        connectionId: { S: connectionId }
      }
    }).promise()
    return {
      statusCode: 200,
      body: 'Connected'
    }
  } catch (e) {
    console.log(e)
    return {
      statusCode: 500,
      body: 'Failed to connect: ' + JSON.stringify(e)
    }
  }
}

const disconnect = async (connectionId) => {
  try {
    await DDB.deleteItem({
      TableName: process.env.CONNECTIONS_TABLE,
      Key: {
        connectionId: { S: connectionId }
      }
    }).promise()
    return {
      statusCode: 200,
      body: 'Disconnected'
    }
  } catch (e) {
    console.log('Failed to disconnect: ' + JSON.stringify(e))
    return {
      statusCode: 500,
      body: 'Failed to disconnect: ' + JSON.stringify(e)
    }
  }
}



module.exports = {
  connect,
  disconnect
}