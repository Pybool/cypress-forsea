const { connect, disconnect } = require('./connection');
const { sendMessageToAll } = require('./send');

exports.handler = async (event, context) => {
  try {
    console.log('event', event);
    const routeKey = event.requestContext && event.requestContext.routeKey;


    // API gateway event
    if (routeKey) {
      switch (routeKey) {
        case '$connect':
          return await connect(event.requestContext.connectionId);
        case '$disconnect':
          return await disconnect(event.requestContext.connectionId);
        default:
          // Nothing for now
          const message = event.body;
          console.log('sender', event.requestContext.connectionId)
          await sendMessageToAll(event.requestContext.connectionId, message);
          break;
      }
      return { statusCode: 200 }
    }
  } catch (e) {
      console.log(e.message);
      throw e
  }
  
};
