const AWS = require('aws-sdk')

const ddb = new AWS.DynamoDB.DocumentClient({ apiVersion: '2012-08-10' })

const { disconnect } = require('./connection')

const apiGatewayManagementApi = new AWS.ApiGatewayManagementApi({
  apiVersion: '2018-11-29',
  endpoint: process.env.API_GATEWAY_URL
})

const getConnectionIds = async () => {
  try {
    const connectionData = await ddb.scan({TableName: process.env.CONNECTIONS_TABLE, ProjectionExpression: 'connectionId'}).promise()
    return connectionData.Items.map(({ connectionId }) => connectionId)
  } catch (e) {
    console.log(e)
    throw e
  }
}

const sendMessage = async (connectionId, data) => {
  try {
    await apiGatewayManagementApi.postToConnection({ ConnectionId: connectionId, Data: data }).promise()
    console.log('sent', data, connectionId)
  } catch (e) {
    console.log(e)
    if (e.statusCode === 410) { // Stale connection - delete
    console.log('disconnect',connectionId)
      await disconnect(connectionId)
    } else {
      throw e
    }
  }
}

const sendMessageToAll = async (sender, data) => {
  try {
    const message = JSON.parse(data)
    if (message.keepAlive) {
      // Don't spam keepalives to listeners
      return []
    }
    const connectionIds = await getConnectionIds()
    console.log(connectionIds)
    const messages = [...new Set(connectionIds)]
    .filter(connectionId => connectionId !== sender)
    .map(async connectionId => {
      return sendMessage(connectionId, JSON.stringify({
        sender,
        connectionId,
        ...message
      }))
    })

    await Promise.allSettled(messages)
  } catch (e) {
    console.error(e)
    return { statusCode: 500, body: JSON.stringify(e.stack) }
  }
  console.log('All sent')
  return { statusCode: 200, body: 'Data sent' }
}

module.exports = {
  sendMessageToAll
}